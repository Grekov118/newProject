$(function () {


  $('.slider-blog__inner').slick({
    dots: true,
    arrows: false,
    fade: true,
    autoplay: true,
    autoplaySpeed: 3000,
  });

  var mixer = mixitup('.product__content');



});