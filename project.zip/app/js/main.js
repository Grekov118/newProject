$ (function () {


$ ('.slider-blog__inner').slick({

});


});